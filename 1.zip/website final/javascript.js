document.addEventListener('DOMContentLoaded', function() {
    console.log("Welcome to CodeConflux!");
});
